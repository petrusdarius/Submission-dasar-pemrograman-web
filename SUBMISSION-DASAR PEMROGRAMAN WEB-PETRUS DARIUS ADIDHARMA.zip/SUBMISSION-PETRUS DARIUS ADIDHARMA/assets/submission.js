function confirmcomment() {
    var bertanya = confirm ("Apakah anda ingin meninggalkan komentar di website ini?");

    if(bertanya === true) {
        comment = "Yeah";
    } else {
        comment = "Nope, I'm find";
    }

    document.getElementById("comment").innerHTML = comment;

    var message = prompt("Your Comment: ");
    if(message!="") {
        document.getElementById("message").innerHTML = "Your comment: " + message;
    }
}